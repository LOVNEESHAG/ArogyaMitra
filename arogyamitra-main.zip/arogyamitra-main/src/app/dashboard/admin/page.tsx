import { redirect } from "next/navigation";

export default function AdminPageRedirect() {
  redirect("/dashboard");
}
