export const PRODUCT_NAME = "Arogya Mitra";
